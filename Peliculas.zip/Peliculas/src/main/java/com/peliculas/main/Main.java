package com.peliculas.main;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.gestion_peliculas.entity.Pelicula;

public class Main {

	 static final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
			.configure() // configures settings from hibernate.cfg.xml
			.build();
	
	static SessionFactory sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();

	public static void main(String[] args) {
		

//		List<Pelicula> peliculas = getPeliculas();
//		for(Pelicula p: peliculas) {
//			System.out.println(p);
//		}
//		System.out.println();
		
	
		

//		List<Pelicula> peliculasRating = getPeliculasPorRating(3);
//		for(Pelicula p: peliculasRating) {
//		System.out.println(p);
//		}
	    
//		List<Pelicula> peliculasGeneros = getPeliculasGenero();
//		for(Pelicula peliculas: peliculasGeneros) {
//			System.out.println(peliculas.getTitulo());
//			System.out.println(peliculas.getGeneros());
//	}
		
		
		//long contador = contadorPeliculas();
			//System.out.println(contador);
		
		long contadorActores = contadorActores();
		System.out.println(contadorActores);
	
		long contadorDirectores = contadorDirectores();
		System.out.println(contadorDirectores);
	
		
	}

	public static List<Pelicula> getPeliculas(){
		
			Session session =sessionFactory.openSession();
			String hplPelicula="from Pelicula as p order by p.titulo";
			Query query =session.createQuery(hplPelicula);
		    List<Pelicula> peliculas =query.getResultList();
		    session.close();
		    return peliculas;
		}
	    
	public static List<Pelicula> getPeliculasPorRating(int rating) {
		Session session = sessionFactory.openSession();
		String hqlPelicula = "from Pelicula as p Where p.rating>:rating order by p.titulo asc";
		Query query = session.createQuery(hqlPelicula);
		query.setParameter("rating", rating);
		List<Pelicula> peliculas = query.getResultList();
		session.close();
		return peliculas;
	}
	
	public static List<Pelicula> getPeliculasGenero(){
		
		Session session =sessionFactory.openSession();
		String hplPelicula="from Pelicula as p inner join fetch p.generos as g";
		Query query =session.createQuery(hplPelicula);
	    List<Pelicula> peliculas =query.getResultList();
	    return peliculas;
	}
	
	public static long contadorPeliculas() {
		Session session =sessionFactory.openSession();
		String hplPelicula="select count(*) from Pelicula as p";
		Query query =session.createQuery(hplPelicula);
		List l = query.getResultList();
		return (Long)l.get(0);
	}
	
	
	public static long contadorActores() {
		Session session =sessionFactory.openSession();
		String hplPelicula="select count(*) from Actor as p";
		Query query =session.createQuery(hplPelicula);
		List l = query.getResultList();
		return (Long)l.get(0);
	}
	public static long contadorDirectores() {
		Session session =sessionFactory.openSession();
		String hplPelicula="select count(*) from Director as p";
		Query query =session.createQuery(hplPelicula);
		List l = query.getResultList();
		return (Long)l.get(0);
	}
	
}

