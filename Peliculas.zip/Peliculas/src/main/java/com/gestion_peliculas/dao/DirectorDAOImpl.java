package com.gestion_peliculas.dao;

import java.util.List;

import com.gestion_peliculas.entity.Director;

public class DirectorDAOImpl implements DirectorDAO {

	public void ingresar(Director director) {
		// TODO Auto-generated method stub
		
	}

	public void modificar(Director director) {
		// TODO Auto-generated method stub
		
	}

	public Director getDirector(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Director> getDirector() {
		// TODO Auto-generated method stub
		return null;
	}

}
