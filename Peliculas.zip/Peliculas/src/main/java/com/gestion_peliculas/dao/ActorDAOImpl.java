package com.gestion_peliculas.dao;

import java.util.List;

import com.gestion_peliculas.entity.Actor;

public class ActorDAOImpl implements ActorDAO {

	public void ingresar(Actor actor) {
		// TODO Auto-generated method stub
		
	}

	public void modificar(Actor actor) {
		// TODO Auto-generated method stub
		
	}

	public Actor getActor(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Actor> getActores() {
		// TODO Auto-generated method stub
		return null;
	}

}
