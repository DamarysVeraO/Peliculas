package com.gestion_peliculas.dao;

import java.util.List;

import com.gestion_peliculas.entity.Actor;

public interface ActorDAO {
	 void ingresar(Actor actor);
	 void modificar(Actor actor);
	 Actor getActor(int id);
	 List<Actor> getActores();
}
