package com.gestion_peliculas.dao;

import java.util.List;

import com.gestion_peliculas.entity.Director;

public interface DirectorDAO {
	void ingresar(	Director director);
	 void modificar(Director director);
	 Director getDirector(int id);
	 List<Director> getDirector();
}
