package com.gestion_peliculas.dao;

import java.util.List;

import com.gestion_peliculas.entity.Genero;



public interface GeneroDAO {
	void ingresar(	Genero genero);
	 void modificar(Genero genero);
	 Genero getGenero(int id);
	 List<Genero> getGenero();
}
