package com.gestion_peliculas.dao;

import java.util.List;

import com.gestion_peliculas.entity.Genero;

public class GeneroDAOImpl implements GeneroDAO{

	public void ingresar(Genero genero) {
		// TODO Auto-generated method stub
		
	}

	public void modificar(Genero genero) {
		// TODO Auto-generated method stub
		
	}

	public Genero getGenero(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Genero> getGenero() {
		// TODO Auto-generated method stub
		return null;
	}

}
