package com.gestion_peliculas.dao;

import java.util.List;

import com.gestion_peliculas.entity.Pelicula;

public class PeliculaDAOImpl implements PeliculaDAO {

	public void ingresar(Pelicula pelicula) {
		// TODO Auto-generated method stub
		
	}

	public void modificar(Pelicula pelicula) {
		// TODO Auto-generated method stub
		
	}

	public Pelicula getPelicula(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Pelicula> getPeliculas() {
		// TODO Auto-generated method stub
		return null;
	}

}
