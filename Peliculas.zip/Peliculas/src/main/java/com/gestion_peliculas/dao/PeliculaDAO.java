package com.gestion_peliculas.dao;

import java.util.List;

import com.gestion_peliculas.entity.Pelicula;



public interface PeliculaDAO {
	 void ingresar(	Pelicula pelicula);
	 void modificar(Pelicula pelicula);
	 Pelicula getPelicula(int id);
	 List<Pelicula> getPeliculas();
}
